import { createFileRoute, Link } from "@/lib/spa-router";
import { useMemo, useState } from "react";
import { Container, DemoNote, PageHeader, meta } from "@/components/site/Chrome";
import { publications, topics } from "@/lib/data";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/publications")({
  head: () => meta("Publications", "Search and filter GeoCam sample publications on Cambodian geoscience by topic and year."),
  component: Pubs,
});

function Pubs() {
  const { t, lang } = useI18n();
  const [q, setQ] = useState("");
  const [topic, setTopic] = useState("All");
  const [year, setYear] = useState("All");
  const years = [...new Set(publications.map((p) => p.year))].sort((a, b) => b - a);
  const list = useMemo(
    () =>
      publications.filter(
        (p) =>
          (topic === "All" || p.topic === topic) &&
          (year === "All" || String(p.year) === year) &&
          `${p.title} ${p.authors} ${p.abstract}`.toLowerCase().includes(q.toLowerCase()),
      ),
    [q, topic, year],
  );
  return (
    <>
      <PageHeader eyebrow={t("publications")} title={t("publications")} sub="Bulletin articles, proceedings and field notes from members." />
      <Container>
        <DemoNote>All entries are sample articles for the prototype, not real publications.</DemoNote>
        <div className="mt-6 grid gap-3 md:grid-cols-[1fr_200px_140px]">
          <label className="sr-only" htmlFor="q">{t("search")}</label>
          <input id="q" className="field" placeholder={`${t("search")}…`} value={q} onChange={(e) => setQ(e.target.value)} />
          <select aria-label="Topic" className="field" value={topic} onChange={(e) => setTopic(e.target.value)}>
            <option>All</option>{topics.map((x) => <option key={x}>{x}</option>)}
          </select>
          <select aria-label="Year" className="field" value={year} onChange={(e) => setYear(e.target.value)}>
            <option>All</option>{years.map((y) => <option key={y}>{y}</option>)}
          </select>
        </div>
        <p className="mt-4 text-sm text-muted-foreground" aria-live="polite">{list.length} results</p>
        <div className="mt-4 space-y-4">
          {list.map((p) => (
            <Link key={p.id} to={"/publications/view?id="+encodeURIComponent(p.id)} className="card-surface block p-6 transition hover:shadow-lg focus-visible:outline-2 focus-visible:outline-blue-600">
              <p className="text-xs font-semibold text-accent">{p.topic} · {p.year} · {p.journal}</p>
              <h2 className="mt-1 text-xl font-semibold">{p.title}</h2>
              <p className="text-sm text-muted-foreground">{p.authors}</p>
              <p className="mt-2 text-sm">{p.abstract}</p><p className="mt-4 font-semibold text-accent">{lang === "km" ? "មើល PDF →" : "View PDF →"}</p>
            </Link>
          ))}
        </div>
      </Container>
    </>
  );
}
