// All content below is SAMPLE / DEMO data for the prototype. No real publications,
// officials, endorsements or government datasets are represented.

export type Article = { id: string; title: string; titleKm?: string; date: string; excerpt: string; status: "draft" | "published"; tag: string };
export type EventItem = { id: string; title: string; date: string; place: string; kind: string; status: "draft" | "published" };
export type Publication = { id: string; title: string; authors: string; year: number; topic: string; journal: string; abstract: string; pdfUrl?: string };
export type Member = { id: string; name: string; affiliation: string; field: string; showInDirectory: boolean; email: string };
export type Application = { id: string; name: string; email: string; category: string; submitted: string; status: "pending" | "approved" | "rejected" };

export const topics = ["Tectonics", "Mineral deposits", "Geochemistry", "Geophysics", "Geohazards"] as const;

export const news: Article[] = [
  { id: "n1", title: "Field school returns to the Cardamom foothills", titleKm: "សាលាវាលត្រឡប់មកជើងភ្នំក្រវាញវិញ", date: "2026-09-28", excerpt: "Students mapped sandstone sequences and laterite profiles during a week-long training camp (sample story).", status: "published", tag: "Education" },
  { id: "n2", title: "Workshop on riverbank erosion along the Mekong", titleKm: "សិក្ខាសាលាស្តីពីការហូរច្រោះច្រាំងទន្លេមេគង្គ", date: "2026-09-10", excerpt: "Members discussed monitoring methods for bank collapse and community awareness (sample story).", status: "published", tag: "Geohazards" },
  { id: "n3", title: "Call for abstracts: Annual Geoscience Forum 2027", titleKm: "ការអំពាវនាវសេចក្តីសង្ខេប៖ វេទិកាភូគព្ភវិទ្យាប្រចាំឆ្នាំ ២០២៧", date: "2026-08-22", excerpt: "Submit research on Indochina tectonics, resources and environment (sample announcement).", status: "published", tag: "Society" },
  { id: "n4", title: "Draft: Groundwater arsenic outreach brief", date: "2026-10-05", excerpt: "Internal draft awaiting editor review.", status: "draft", tag: "Geochemistry" },
];

export const events: EventItem[] = [
  { id: "e1", title: "Annual Geoscience Forum 2027", date: "2027-02-18", place: "Phnom Penh (venue TBC)", kind: "Conference", status: "published" },
  { id: "e2", title: "Laterite & weathering profiles field trip", date: "2026-11-21", place: "Kampong Thom Province", kind: "Field trip", status: "published" },
  { id: "e3", title: "Webinar: Intro to QGIS for geologists", date: "2026-11-05", place: "Online", kind: "Webinar", status: "published" },
  { id: "e4", title: "Student poster evening", date: "2026-12-12", place: "Phnom Penh", kind: "Meetup", status: "draft" },
];

export const publications: Publication[] = [
  { id: "p1", title: "Structural framework of the Indochina block margin: a review (sample)", authors: "Sok, D.; Chan, R.", year: 2025, topic: "Tectonics", journal: "GeoCam Bulletin (sample)", abstract: "Illustrative review of fault systems bordering the Indochina terrane and their Cenozoic reactivation." },
  { id: "p2", title: "Gold mineralisation styles in northeastern Cambodia (sample)", authors: "Kim, S.; Lim, P.", year: 2024, topic: "Mineral deposits", journal: "GeoCam Bulletin (sample)", abstract: "A sample synthesis of orogenic and epithermal gold occurrence models discussed in open literature." },
  { id: "p3", title: "Arsenic in shallow groundwater of the Mekong floodplain (sample)", authors: "Heng, M.", year: 2023, topic: "Geochemistry", journal: "Proceedings (sample)", abstract: "Example article on redox controls of arsenic mobilisation in Holocene sediments." },
  { id: "p4", title: "Passive seismic HVSR surveys for urban site characterisation (sample)", authors: "Ny, V.; Sar, K.", year: 2025, topic: "Geophysics", journal: "GeoCam Bulletin (sample)", abstract: "Demonstration of low-cost ambient noise methods for sediment thickness estimation." },
  { id: "p5", title: "Landslide susceptibility indicators in upland road cuts (sample)", authors: "Chea, L.", year: 2024, topic: "Geohazards", journal: "Proceedings (sample)", abstract: "Example indicators combining slope, lithology and rainfall for qualitative screening." },
  { id: "p6", title: "Basalt plateaus of the east: petrography notes (sample)", authors: "Phan, T.", year: 2022, topic: "Geochemistry", journal: "Field Notes (sample)", abstract: "Sample notes on Cenozoic basalt textures and weathering to red soils." },
  { id: "p7", title: "Gravity data compilation workflow for basin studies (sample)", authors: "Sok, D.", year: 2023, topic: "Geophysics", journal: "Field Notes (sample)", abstract: "Illustrative workflow for open-source gravity grid processing." },
];

export const members: Member[] = [
  { id: "m1", name: "Dara Sok", affiliation: "University (sample)", field: "Structural geology", showInDirectory: true, email: "dara@example.org" },
  { id: "m2", name: "Sophea Kim", affiliation: "Consultancy (sample)", field: "Economic geology", showInDirectory: true, email: "sophea@example.org" },
  { id: "m3", name: "Private member", affiliation: "—", field: "Hydrogeology", showInDirectory: false, email: "hidden@example.org" },
  { id: "m4", name: "Vannak Ny", affiliation: "Research institute (sample)", field: "Geophysics", showInDirectory: true, email: "vannak@example.org" },
  { id: "m5", name: "Lina Chea", affiliation: "NGO (sample)", field: "Geohazards", showInDirectory: true, email: "lina@example.org" },
];

export const applications: Application[] = [
  { id: "a1", name: "Rithy Chan", email: "rithy@example.org", category: "Professional", submitted: "2026-10-09", status: "pending" },
  { id: "a2", name: "Malis Heng", email: "malis@example.org", category: "Student", submitted: "2026-10-12", status: "pending" },
  { id: "a3", name: "Kosal Lim", email: "kosal@example.org", category: "Associate", submitted: "2026-10-14", status: "pending" },
];

export const researchAreas = [
  { key: "Tectonics", km: "តិចតូនិក", text: "Cambodia sits within the Indochina block. Members study Paleozoic–Mesozoic suturing, Cenozoic fault reactivation and basin evolution around the Tonle Sap and Mekong." },
  { key: "Mineral deposits", km: "ប្រាក់បញ្ញើរ៉ែ", text: "Research on gold, base metals, gemstones, bauxite and industrial minerals — with emphasis on responsible, transparent exploration science." },
  { key: "Geochemistry", km: "ភូគីមីវិទ្យា", text: "Groundwater quality, arsenic in floodplain aquifers, soil and laterite geochemistry, and isotopic dating of igneous suites." },
  { key: "Geophysics", km: "ភូរូបវិទ្យា", text: "Gravity, magnetics, resistivity and passive seismic methods for basin, groundwater and engineering investigations." },
  { key: "Geohazards", km: "គ្រោះធម្មជាតិភូគព្ភ", text: "Riverbank erosion, landslides in upland areas, subsidence, flooding interactions and community-oriented risk communication." },
];
